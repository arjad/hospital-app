function price_assign()
{
    var a = document.getElementById("myprice").value;

    console.log(a)
    

}