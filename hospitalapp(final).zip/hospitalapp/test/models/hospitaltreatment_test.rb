require 'test_helper'

class HospitaltreatmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
