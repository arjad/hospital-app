
admin = User.create(
    name:"adminname",
    usertype:"admin",
    email:"admin@a.com",
    password:"123456"
)